#!/usr/bin/env python
#
# Code from Cray Programming Models Examples
#
# Python2 MPI (mpi4py)

from mpi4py import MPI
import numpy as np

nmax=140000
pi=3.14159265358979323846264338327950288

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

istart = rank * nmax//size
iend = (rank+1) * nmax//size - 1
if rank == size-1:
  iend = nmax-1

if rank==0:
  print("PI approximation by Python3 mpi4py using %d processes" %size)

mycount = 0

for i in range(istart,iend+1):
  x = (i+0.5)/nmax
  for j in range(nmax):
    y = (j+0.5)/nmax
    if ( x*x + y*y < 1.0 ):
      mycount+=1

local_count = np.zeros(1)
count = np.zeros(1)
local_count[0] = mycount
comm.Reduce(local_count, count, op=MPI.SUM, root=0)
mypi=4.0*count[0]/nmax/nmax

if rank==0:
  print("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%"  %(pi,mypi,abs(mypi-pi)/pi*100) )



  
