// Timer for C - returning double
// On Cray CLE there are choices with better resolution and cost
// but this is not bad and is more portable to modern Linux.

typedef double gettime_t;

#define USE_CLOCK_GETTIME

#ifdef USE_CLOCK_GETTIME

#include <time.h>

static struct timespec ts_offset;
static int initialized=0;

static void timer_initialize(){

  clock_gettime(CLOCK_REALTIME,&ts_offset);

}

gettime_t gettime(){
  struct timespec ts;
  if (initialized++==0){
    timer_initialize();
  }

  clock_gettime(CLOCK_REALTIME,&ts);

  return (double)((ts.tv_sec-ts_offset.tv_sec)+
                  (double)(ts.tv_nsec-ts_offset.tv_nsec)/1.e9);
}

#endif
