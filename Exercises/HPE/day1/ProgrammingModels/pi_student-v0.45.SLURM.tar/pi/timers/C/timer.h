typedef double gettime_t;
extern gettime_t gettime(void);
