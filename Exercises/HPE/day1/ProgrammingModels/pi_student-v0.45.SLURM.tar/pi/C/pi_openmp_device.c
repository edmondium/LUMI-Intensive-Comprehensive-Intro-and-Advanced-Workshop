// Code from Cray Programming Models Examples
//
// C/OpenMP target

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

int main(int argc, char **argv){
  const long long nmax=140000;
  const double pi=3.14159265358979323846264338327950288;
  double diff,mypi,x,y;
  long long count;
  int i,j;

  printf("PI approximation by OpenMP target program using %d GPU\n",1);

  count = 0;
#pragma omp target map(tofrom: count)
#pragma omp teams distribute collapse(2) reduction(+:count)

  for(i=0;i<nmax;i++){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) count++;
    }      
  }

  mypi=4*(double)count/nmax/nmax;

  printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
         pi,mypi,fabs(mypi-pi)/pi*100);

  return EXIT_SUCCESS;

}


  
