// Code from Cray Programming Models Examples
//
// C/SHMEM

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mpp/shmem.h>

int main(int argc, char **argv){
  const long long nmax=140000;
  const double pi=3.14159265358979323846264338327950288;
  double diff,mypi,x,y;
  long long mycount;
  static long long count;
  int i,j,istart,iend,mype,npes;

  shmem_init();
  mype = shmem_my_pe();
  npes = shmem_n_pes();

  istart = mype * nmax/npes;
  iend = (mype+1) * nmax/npes - 1;
  if (mype == npes-1) iend = nmax-1 ; // for non divisors

  if (mype==0) printf("PI approximation by SHMEM program using %d PEs\n",npes);

  mycount = 0;
  shmem_barrier_all();

  for(i=istart;i<=iend;i++){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) mycount++;
    }      
  }

  // Could do a reduction here but this illustrates a single-sided operation
  shmem_longlong_add(&count,mycount,0);
  shmem_barrier_all();

  shmem_finalize();

  mypi=4*(double)count/nmax/nmax;

  if (!mype)
    printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
           pi,mypi,fabs(mypi-pi)/pi*100);

  return EXIT_SUCCESS;

}


  
