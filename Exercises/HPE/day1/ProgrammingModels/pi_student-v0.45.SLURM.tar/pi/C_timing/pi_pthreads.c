// Code from Cray Programming Models Examples
//
// C/pthreads

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "params.h" // For nmax
#include "timer.h"

int nthreads;
const double pi=3.14159265358979323846264338327950288;
long long count;
pthread_mutex_t count_mutex;

void *worker(void* data){
  long long mycount;
  double x,y;
  int i,j,istart,iend,tid;

  tid=*((int *)data);

  istart = tid * nmax/nthreads;
  iend = (tid+1) * nmax/nthreads - 1;
  if (tid == nthreads-1) iend = nmax ; // for non divisors
 
  mycount = 0;
  for(i=istart;i<=iend;i++){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) mycount++;
    }      
  }

  pthread_mutex_lock(&count_mutex);
  count+=mycount; 
  pthread_mutex_unlock(&count_mutex);

  return NULL;
}

int main(int argc, char **argv){
  double diff,mypi,x,y;
  long long mycount;
  int tid,rc,*i;
  pthread_t *threads;
  char *oenv;
  gettime_t t1,t2;

  oenv = getenv("OMP_NUM_THREADS");
  if (oenv==NULL){
    nthreads=1;
  } else {
    nthreads=atoi(oenv);
  }
  printf("PI approximation by pthreads program using %d threads\n",nthreads);

  if (nthreads>1){
    threads = (pthread_t *)malloc((size_t)nthreads*sizeof(pthread_t));
    pthread_mutex_init(&count_mutex,NULL);
  }

  t1=gettime();

  for(tid=1;tid<nthreads;tid++){
    i = (int *)malloc(sizeof(*i));
    *i = tid;
    rc = pthread_create(&threads[tid], NULL, worker, (void *)i);
    if (rc){
      printf("ERROR; return code from pthread_create() is %d\n", rc);
      exit(22);
    }
  }
  i = (int *)malloc(sizeof(*i));
  *i = 0;
  worker((void *)i);   
  for(tid=1;tid<nthreads;tid++){
    void *status;
    rc = pthread_join(threads[tid], &status);
   }

  mypi=4*(double)count/nmax/nmax;

  t2=gettime();

  printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
         pi,mypi,fabs(mypi-pi)/pi*100);
  printf("Elapsed time was %.2fs\n",t2-t1);

  pthread_exit(0);

  return EXIT_SUCCESS;

}


  
