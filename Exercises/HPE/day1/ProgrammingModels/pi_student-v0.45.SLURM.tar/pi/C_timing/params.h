static const long long nmax=140000;
