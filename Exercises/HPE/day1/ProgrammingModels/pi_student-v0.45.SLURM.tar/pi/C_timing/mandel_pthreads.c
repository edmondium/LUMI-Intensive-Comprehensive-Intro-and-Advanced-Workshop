// Code from Cray Programming Models Examples
//
// C pthreads

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>
#include "params_mandel.h" // For nmax_x,nmax_y,max_cycles
#include "timer.h"

static int nthreads;
static long long count;
static pthread_mutex_t count_mutex;
static double c1_r,c1_i,c2_r,c2_i;

long long inside_count(int istart,int iend,int jstart,int jend){
  long long mycount;
  double z_r,z_i,z_rs,z_is,area,c_r,c_i;
  int i,j,cycle;

  mycount=0;

  for(i=istart;i<=iend;i++){
    c_r=c1_r + (c2_r-c1_r)*((double)i/nmax_x);
    for(j=jstart;j<=jend;j++){
      c_i=c1_i + (c2_i-c1_i)*((double)j/nmax_y);

      // First iteration starts with z=0
      z_r = c_r;
      z_i = c_i;
      z_rs = z_r*z_r;
      z_is = z_i*z_i;

      for(cycle=0;cycle<=max_cycles;cycle++){
	if (z_rs+z_is > 4.0) break;
          z_rs = z_r*z_r;
          z_is = z_i*z_i;
          z_i = 2*z_r*z_i + c_i;
          z_r = (z_rs - z_is) + c_r;
       }
      if (cycle>max_cycles){ mycount++ ;};
    }
  }

  return mycount;

}

void *worker(void * data){
  int istart,iend,jstart,jend,cycle,tid;
  long long mycount;

  tid=*((int *) data);

  // Deompose X (real) to tasks
  istart = tid *(nmax_x/nthreads);
  iend  = istart + (nmax_x/nthreads) - 1;

  if (tid==nthreads-1) { iend = nmax_x ;}

  jstart = 0;
  jend = nmax_y;

  mycount = inside_count(istart,iend,jstart,jend) ;
 
  pthread_mutex_lock(&count_mutex);
  count+=mycount;
  pthread_mutex_unlock(&count_mutex);

  printf("tid=%d istart=%d iend=%d mycount=%lld\n",tid,istart,iend,mycount);

  return NULL;
}

int main(int argc, char **argv){
  int tid,rc,*i;
  pthread_t *threads;
  char *oenv;
  gettime_t t1,t2;
  double area; 

  c1_r = -2.25; c1_i = -1.5;
  c2_r =  0.75; c2_i =  1.5;

  oenv = getenv("OMP_NUM_THREADS");
  if (oenv==NULL){
    nthreads=1;
  } else {
    nthreads=atoi(oenv);
  }
  printf("approximationgr to Mandelbrot area by pthreads program using %d threads\n",nthreads);

  if (nthreads>1){
    threads = (pthread_t *)malloc((size_t)nthreads*sizeof(pthread_t));
    pthread_mutex_init(&count_mutex,NULL);
  }

  t1=gettime();

  for(tid=1;tid<nthreads;tid++){
    i = (int *)malloc(sizeof(*i));
    *i = tid;
    rc = pthread_create(&threads[tid], NULL, worker, (void *)i);
    if (rc){
      printf("ERROR; return code from pthread_create() is %d\n", rc);
      exit(22);
    }
  }
  i = (int *)malloc(sizeof(*i));
  *i = 0;
  worker((void *)i);
  for(tid=1;tid<nthreads;tid++){
    void *status;
    rc = pthread_join(threads[tid], &status);
   }


  area=(double)count*((c2_r-c1_r)/nmax_x)*((c2_i-c1_i)/nmax_y);
  t2=gettime();

  //  printf("   area = %21.18f\n\n",area);
  printf("   area = %21.18f (%lld/%lld)\n\n",area,count,nmax_x*nmax_y);

  printf("Elapsed time was %.2fs\n",t2-t1);

}


  
