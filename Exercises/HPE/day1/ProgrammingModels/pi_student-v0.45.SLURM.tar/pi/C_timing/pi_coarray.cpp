// Code from Cray Programming Models Examples
//
// Coarray C++

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "params.h" // For nmax
extern "C" {
#include "timer.h"
}

#include <coarray_cpp.h>
using namespace coarray_cpp;

int main(int argc, char **argv){
  const double pi=3.14159265358979323846264338327950288;
  double diff,mypi,x,y;
  // Long should be OK, likely to be LP64
  long mycount;
  coarray<coatomic_long>count;
  int i,j,istart,iend;
  gettime_t t1,t2;

  t1=gettime();

  istart = this_image() * nmax/num_images();
  iend = (this_image()+1) * nmax/num_images() - 1;
  if (this_image() == num_images()-1) iend = nmax-1 ; // for non divisors

  if (this_image()==0) printf("PI approximation by coarray C++ program using %lu images\n",num_images());
 
  count = 0;
  sync_all();

  mycount = 0;
  for(i=istart;i<=iend;i++){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) mycount++;
    }      
  }

  count(0)+=mycount;

  sync_all();

  mypi=4*(double)count/nmax/nmax;

  t2=gettime();

  if (!this_image()){
    printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
           pi,mypi,fabs(mypi-pi)/pi*100);
    printf("Elapsed time was %.2fs\n",t2-t1);
   }
}


  
