// Code from Cray Programming Models Examples
//
// C/OpenMP

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include "params.h" // For nmax
#include "timer.h"

int main(int argc, char **argv){
  const double pi=3.14159265358979323846264338327950288;
  double diff,mypi,x,y;
  long long count;
  int i,j;
  gettime_t t1,t2;

  printf("PI approximation by OpenMP program using %d threads\n",
         omp_get_max_threads());

  t1=gettime();

  count = 0;
#pragma omp parallel for default(none) private(j,x,y) shared(nmax) reduction(+:count)
  for(i=0;i<nmax;i++){
    x = (i+0.5)/nmax;
    for(j=0;j<nmax;j++){
      y = (j+0.5)/nmax;
      if ( x*x + y*y < 1.0 ) count++;
    }      
  }

  mypi=4*(double)count/nmax/nmax;

  t2=gettime();

  printf("   PI = %20.18f\n myPI = %20.18f\n diff = %10.8f%%\n",
         pi,mypi,fabs(mypi-pi)/pi*100);
  printf("Elapsed time was %.2fs\n",t2-t1);

  return EXIT_SUCCESS;

}


  
