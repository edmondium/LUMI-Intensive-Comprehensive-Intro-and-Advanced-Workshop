static const long long nmax_x=4000;
static const long long nmax_y=4000;
static const int max_cycles = 1000;



