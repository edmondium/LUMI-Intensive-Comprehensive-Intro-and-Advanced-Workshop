# For SHMEM instest of MPI
module swap cray-mpich cray-openshmemx
