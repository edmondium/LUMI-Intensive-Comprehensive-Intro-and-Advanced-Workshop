# Modules setup for AMD GPU exercises on LUMI-G
module swap craype-x86-rome craype-x86-trento
module load craype-accel-amd-gfx90a
module load rocm
